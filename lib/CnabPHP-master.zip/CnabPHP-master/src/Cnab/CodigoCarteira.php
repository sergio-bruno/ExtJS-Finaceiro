<?php

namespace Cnab;

class CodigoCarteira
{
    const COBRANCA_SIMPLES = 1;
    const COBRANCA_VINCULADA = 2;
    const COBRANCA_CAUCIONADA = 3;
    const COBRANCA_DESCONTADA = 4;
    const COBRANCA_VENDOR = 5;
}
