<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>BANCO DO BRASIL - RETORNO CNAB 240</title>

<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style>
</head>

<body>
<table width="990" height="84" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" style="border:0px solid #000000"> 
  <tr>
    <td height="20" valign="top"><div align="center"><img src="../../../../figuras/logo-big.png" width="350" height="138" /></div></td>
  </tr>
  <tr>
    <td width="990" height="20" valign="top"><div align="center"><span class="titulo_das_tabelas">ARQUIVO DE RETORNO </span>- BANCO DO BRASIL - CNAB 240 </div></td>
  </tr>
  <tr>
<td height="19"><form action="retorno2.php" method="post" enctype="multipart/form-data" name="enviar" id="enviar">
  <table width="100%" border="0" cellspacing="2" cellpadding="2">
    
    
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td width="32%"><div align="right"><span class="label_normal">Arquivo de Retorno:</span> </div></td>
      <td width="67%"><div align="left">
        <input type="file" name="arquivo" id="arquivo" />
      </div></td>
    </tr>
    
    <tr>
      <td>&nbsp;</td>
      <td><div align="left">
        <input name="Proximo" type="submit" class="label_titulo" value="Avan&ccedil;ar" />
      </div></td>
    </tr>
  </table>
</form></td>
</tr>
<td height="2"></tr>
</table>
</body>

</html>
